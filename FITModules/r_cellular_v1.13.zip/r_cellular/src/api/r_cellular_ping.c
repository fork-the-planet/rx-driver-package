/*
 * Copyright (c) 2025 Renesas Electronics Corporation and/or its affiliates
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**********************************************************************************************************************
 * File Name    : r_cellular_ping.c
 * Description  : Functions for performing PING.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "cellular_private_api.h"
#include "cellular_freertos.h"
#include "at_command.h"

/**********************************************************************************************************************
 * Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Private (static) variables and functions
 *********************************************************************************************************************/

/************************************************************************
 * Function Name  @fn            R_CELLULAR_Ping
 ***********************************************************************/
e_cellular_err_t R_CELLULAR_Ping(st_cellular_ctrl_t * const p_ctrl, const uint8_t * const p_host,
                                    const st_cellular_ping_cfg_t * const p_cfg)
{
    uint32_t                   preemption    = 0;
    e_cellular_err_t           ret           = CELLULAR_SUCCESS;
    e_cellular_err_semaphore_t semaphore_ret = CELLULAR_SEMAPHORE_SUCCESS;

    preemption = cellular_interrupt_disable();
    if ((NULL == p_ctrl) || (NULL == p_host))
    {
        ret = CELLULAR_ERR_PARAMETER;
    }

    if ((CELLULAR_SUCCESS == ret) && (NULL != p_cfg))
    {
        if (((p_cfg->count < CELLULAR_PING_REQ_MIN) || (p_cfg->count > CELLULAR_PING_REQ_MAX) ||
            (p_cfg->len < CELLULAR_PING_MES_MIN) || (p_cfg->len > CELLULAR_PING_MES_MAX) ||
            (p_cfg->interval < CELLULAR_PING_INTER_MIN) || (p_cfg->interval > CELLULAR_PING_INTER_MAX) ||
            (p_cfg->timeout < CELLULAR_PING_TIMEOUT_MIN) || (p_cfg->timeout > CELLULAR_PING_TIMEOUT_MAX)))
        {
            ret = CELLULAR_ERR_PARAMETER;
        }
    }

    if (CELLULAR_SUCCESS == ret)
    {
        if (0 != (p_ctrl->running_api_count % 2))
        {
            ret = CELLULAR_ERR_OTHER_API_RUNNING;
        }
        else if (CELLULAR_SYSTEM_CLOSE == p_ctrl->system_state)
        {
            ret = CELLULAR_ERR_NOT_OPEN;
        }
        else if (CELLULAR_SYSTEM_OPEN == p_ctrl->system_state)
        {
            ret = CELLULAR_ERR_NOT_CONNECT;
        }
        else
        {
            p_ctrl->running_api_count += 2;
        }
    }
    cellular_interrupt_enable(preemption);

    if (CELLULAR_SUCCESS == ret)
    {
        semaphore_ret = cellular_take_semaphore(p_ctrl->at_semaphore);
        if (CELLULAR_SEMAPHORE_SUCCESS == semaphore_ret)
        {
            ret = atc_ping(p_ctrl, p_host, p_cfg);
            cellular_give_semaphore(p_ctrl->at_semaphore);
        }
        else
        {
            ret = CELLULAR_ERR_OTHER_ATCOMMAND_RUNNING;
        }
        p_ctrl->running_api_count -= 2;
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function R_CELLULAR_Ping
 *********************************************************************************************************************/
