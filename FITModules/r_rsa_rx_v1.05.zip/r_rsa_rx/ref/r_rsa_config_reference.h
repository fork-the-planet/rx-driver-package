/* Generated configuration header file - do not edit */
/*​
* Copyright (c) 2025 Renesas Electronics Corporation and/or its affiliates​
*​
* SPDX-License-Identifier: BSD-3-Clause​
*/
/*******************************************************************************************************************//**
 * @file         r_rsa_config.h
 * @brief        RSA Library config file.
 **********************************************************************************************************************/
#ifndef R_RSA_CONFIG_H
    #define R_RSA_CONFIG_H

/***********************************************************************************************************************
Configuration Options
***********************************************************************************************************************/

#endif /* R_RSA_CONFIG_H */
