PLEASE REFER TO THE APPLICATION NOTE FOR THIS MIDDLEWARE FOR MORE INFORMATION

r_usb_hhid
=======================

Document Number 
---------------
R01AN2028EJ
R01AN2028JJ

Version
-------
v1.45

Overview
--------
USB Host Human Interface Device Class Driver (HHID)

Features
--------
USB host HID class driver conforms to the USB HID class specification 
and implements communication with HID devices.


Supported MCUs
--------------
* RX64M Group
* RX71M Group
* RX65N Group
* RX66T Group
* RX72T Group
* RX72M Group
* RX72N Group
* RX66N Group
* RX671 Group


Boards Tested On
----------------
* RSKRX64M
* RSKRX71M
* RSKRX65N
* RSKRX65N_2MB
* RSKRX72T
* RSKRX72M
* RSKRX72N
* RSKRX671


Limitations
-----------

Peripherals Used Directly
-------------------------


Required Packages
-----------------
* r_bsp
* r_usb_basic

How to add to your project
--------------------------

Toolchain(s) Used
-----------------
* Renesas RX v.3.07.00
* GCC for Renesas RX 8.3.0.202411
* IAR C/C++ Compiler for Renesas version 5.10.1

File Structure
--------------
r_usb_hhid
|   readme.txt
|   r_usb_hhid_if.h
|
+---doc
|     \en
|     |   r01an2028ej0145_usb.pdf
|     \jp
|         r01an2028jj0145_usb.pdf
|
+---ref
|       r_usb_hhid_config_reference.h
|
\---src
     |  r_usb_hhid_api.c
     |  r_usb_hhid_driver.c
     |
     \---inc
             r_usb_hhid.h
