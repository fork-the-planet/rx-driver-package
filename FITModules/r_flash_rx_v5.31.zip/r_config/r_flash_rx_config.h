/*
* Copyright (C) 2014-2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/***********************************************************************************************************************
 * File Name    : r_flash_rx_config_reference.h
 * Description  : Configures the FLASH API module for RX200 and RX600 Series MCU's.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
*           12.04.2014 1.00    First Release
*           22.12.2014 1.10    Added flash type usage comments.
*           25.06.2015 1.20    Added FLASH_CFG_CODE_FLASH_RUN_FROM_ROM.
*         : 12.10.2016 2.00    Modified for BSPless operation (added FLASH_CFG_USE_FIT_BSP).
*         : 19.04.2019 4.00    Removed BSPless operation (FLASH_CFG_USE_FIT_BSP).
*                              Removed flash type 2 only operation (FLASH_CFG_FLASH_READY_IPL).
*                              Removed flash type 2 only operation (FLASH_CFG_IGNORE_LOCK_BITS).
*         : 19.07.2019 4.20    Modified comments (FLASH_CFG_CODE_FLASH_ENABLE, FLASH_CFG_CODE_FLASH_RUN_FROM_ROM).
*         : 09.09.2019 4.30    Modified comments (FLASH_CFG_CODE_FLASH_ENABLE, FLASH_CFG_CODE_FLASH_RUN_FROM_ROM).
*         : 20.03.2025 5.22    Changed the disclaimer in program sources
*         : 31.07.2025 5.30    Fixed comments.
***********************************************************************************************************************/
#ifndef FLASH_CONFIG_HEADER_FILE
#define FLASH_CONFIG_HEADER_FILE

/***********************************************************************************************************************
 Configuration Options
 ***********************************************************************************************************************/
/* SPECIFY WHETHER TO INCLUDE CODE FOR API PARAMETER CHECKING
 * Setting to BSP_CFG_PARAM_CHECKING_ENABLE utilizes the system default setting
 * Setting to 1 includes parameter checking; 0 compiles out parameter checking
 */
#define FLASH_CFG_PARAM_CHECKING_ENABLE     (1)


/******************************************************************************
 ENABLE CODE FLASH PROGRAMMING
******************************************************************************/
/* If you are only using data flash, set this to 0.
 * Setting to 1 includes code to program the ROM area. When programming ROM,
 * code must be executed from RAM, except under certain restrictions for flash
 * type 3.
 */
#define FLASH_CFG_CODE_FLASH_ENABLE (0)


/******************************************************************************
 ENABLE BGO/NON-BLOCKING DATA FLASH OPERATIONS
******************************************************************************/
/* Setting this to 0 forces data flash API function to block until completed.
 * Setting to 1 places the module in BGO (background operations) mode. In BGO 
 * mode, data flash operations return immediately after the operation has been 
 * started. Notification of the operation completion is done via the callback 
 * function. 
 */
#define FLASH_CFG_DATA_FLASH_BGO   (0)


/******************************************************************************
 ENABLE BGO/NON-BLOCKING CODE FLASH (ROM) OPERATIONS
******************************************************************************/
/* Setting this to 0 forces ROM API function to block until completed.
 * Setting to 1 places the module in BGO (background operations) mode. In BGO 
 * mode, ROM operations return immediately after the operation has been started.
 * Notification of the operation completion is done via the callback function. 
 * When reprogramming ROM, THE RELOCATABLE VECTOR TABLE AND CORRESPONDING
 * INTERRUPT ROUTINES MUST BE IN RAM.  
 */
#define FLASH_CFG_CODE_FLASH_BGO   (0)


/******************************************************************************
 ENABLE CODE FLASH SELF-PROGRAMMING
******************************************************************************/
/* Set this to 0 when programming code flash while executing in RAM.
 * Set this to 1 when programming code flash while executing from another
 * segment in ROM (possible only with RX64M, RX71M, RX65N-2, RX72M groups).
 */
#define FLASH_CFG_CODE_FLASH_RUN_FROM_ROM   (0)


#endif /* FLASH_CONFIG_HEADER_FILE */
