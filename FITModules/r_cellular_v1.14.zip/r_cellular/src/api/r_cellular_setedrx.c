/*
 * Copyright (c) 2025 Renesas Electronics Corporation and/or its affiliates
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**********************************************************************************************************************
 * File Name    : r_cellular_setedrx.c
 * Description  : Function to set the eDRX of the module.
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "cellular_private_api.h"
#include "cellular_freertos.h"
#include "at_command.h"

/**********************************************************************************************************************
 * Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Private (static) variables and functions
 *********************************************************************************************************************/

/************************************************************************
 * Function Name  @fn            R_CELLULAR_SetEDRX
 ***********************************************************************/
e_cellular_err_t R_CELLULAR_SetEDRX(st_cellular_ctrl_t * const p_ctrl, const st_cellular_edrx_config_t * const p_config,
                                        st_cellular_edrx_config_t * const p_result)
{
    uint32_t                   preemption    = 0;
    e_cellular_err_t           ret           = CELLULAR_SUCCESS;
    e_cellular_err_semaphore_t semaphore_ret = CELLULAR_SEMAPHORE_SUCCESS;

    preemption = cellular_interrupt_disable();
    if ((NULL == p_ctrl) || (NULL == p_config))
    {
        ret = CELLULAR_ERR_PARAMETER;
    }
    else
    {
        if (((CELLULAR_EDRX_MODE_INIT < p_config->edrx_mode) ||
            (CELLULAR_EDRX_MODE_INVALID > p_config->edrx_mode)) ||
                ((CELLULAR_EDRX_CYCLE_5_SEC > p_config->edrx_cycle) ||
                (CELLULAR_EDRX_CYCLE_2621_SEC < p_config->edrx_cycle)) ||
                    ((CELLULAR_PTW_CYCLE_1_SEC > p_config->ptw_cycle) ||
                    (CELLULAR_PTW_CYCLE_20_SEC < p_config->ptw_cycle)))
        {
            ret = CELLULAR_ERR_PARAMETER;
        }
        else if (0 != (p_ctrl->running_api_count % 2))
        {
            ret = CELLULAR_ERR_OTHER_API_RUNNING;
        }
        else if (CELLULAR_SYSTEM_CLOSE == p_ctrl->system_state)
        {
            ret = CELLULAR_ERR_NOT_OPEN;
        }
        else
        {
            p_ctrl->running_api_count += 2;
        }
    }
    cellular_interrupt_enable(preemption);

    if (CELLULAR_SUCCESS == ret)
    {
        semaphore_ret = cellular_take_semaphore(p_ctrl->at_semaphore);
        if (CELLULAR_SEMAPHORE_SUCCESS == semaphore_ret)
        {
            ret = atc_sqnedrx(p_ctrl, p_config);
            if ((CELLULAR_SUCCESS == ret) && (NULL != p_result))
            {
                p_ctrl->recv_data = p_result;
                ret               = atc_sqnedrx_check(p_ctrl);
                p_ctrl->recv_data = NULL;
                cellular_delay_task(1000);
            }
            cellular_give_semaphore(p_ctrl->at_semaphore);
        }
        else
        {
            ret = CELLULAR_ERR_OTHER_ATCOMMAND_RUNNING;
        }
        p_ctrl->running_api_count -= 2;
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function R_CELLULAR_SetEDRX
 *********************************************************************************************************************/
