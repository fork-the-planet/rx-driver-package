/*
* Copyright (c) 2014(2025) Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/***********************************************************************************************************************
 * File Name    : r_usb_hcdc_driver.c
 * Description  : USB Host CDC Driver
 ***********************************************************************************************************************/
/**********************************************************************************************************************
 * History   : DD.MM.YYYY Version Description
 *           : 01.09.2014 1.00    First Release
 *           : 01.06.2015 1.01    Added RX231.
 *           : 29.12.2015 1.02    Minor Update.
 *           : 30.11.2018 1.10    Supporting Smart Configurator
 *           : 31.05.2019 1.11    Added support for GNUC and ICCRX.
 *           : 30.06.2020 1.20    Added support for RTOS.
 *           : 30.04.2024 1.30    Added support for RX261.
 *           : 20.03.2025 1.31    Changed the disclaimer.
 ***********************************************************************************************************************/

/******************************************************************************
Includes <System Includes> , "Project Includes"
 ******************************************************************************/
#include "r_usb_hcdc.h"

#if defined(USB_CFG_HCDC_USE)

#if (BSP_CFG_RTOS_USED == 0)    /* Non-OS */
/******************************************************************************
 Macro definitions
 ******************************************************************************/

/******************************************************************************
 Typedef definitions
 ******************************************************************************/

/******************************************************************************
 Exported global variables (to be accessed by other files)
 ******************************************************************************/

/******************************************************************************
 Private global variables and functions
 ******************************************************************************/
static void usb_hcdc_device_state (uint16_t data, uint16_t state);


/******************************************************************************
 * Function Name: usb_hcdc_pipe_info
 * Description  : Host Pipe Information check and EP Table Set
 * Arguments    : uint8_t *p_table      : Check Start Descriptor address
                : uint16_t length       : Configuration Descriptor Length
 * Return Value : uint16_t              : USB_OK / USB_ERROR
 ******************************************************************************/
uint16_t usb_hcdc_pipe_info (uint8_t *p_table, uint16_t length)
{
    uint16_t        ofdsc;
    uint16_t        retval;
    int16_t         in_pipe;
    int16_t         out_pipe;

    uint8_t         pipe_no;

    /* Check Endpoint Descriptor */
    ofdsc = p_table[0];

    /* Pipe initial */
    in_pipe     = USB_NOPORT;
    out_pipe    = USB_NOPORT;

    /* WAIT_LOOP */
    while (ofdsc < length )
    {
        if (USB_DT_ENDPOINT == p_table[ofdsc + 1])
        {
            /* Endpoint Descriptor */
            pipe_no = usb_cstd_pipe_table_set (USB_HCDC, &p_table[ofdsc]);
            if (USB_CFG_HCDC_BULK_OUT == pipe_no)
            {
                out_pipe = USB_YES;
            }
            else if (USB_CFG_HCDC_BULK_IN == pipe_no)
            {
                in_pipe = USB_YES;
            }
            else
            {
                /* Do Nothing */
            }
        }
        ofdsc +=  p_table[ofdsc];
    }

    if ((USB_NOPORT != in_pipe) && (USB_NOPORT != out_pipe))
    {
        retval = USB_OK;
    }
    else
    {
        retval = USB_ERROR;
    }

    return retval;
}
/******************************************************************************
 End of function usb_hcdc_pipe_info
 ******************************************************************************/


/******************************************************************************
 * Function Name: usb_hcdc_registration
 * Description  : Registration of Communications Devices Driver
 * Arguments    : none
 * Return Value : none
 ******************************************************************************/
void usb_hcdc_registration (void)
{
    usb_hcdreg_t    driver;

    /* Driver registration */
    driver.ifclass      = USB_CFG_HCDC_IFCLS;            /* CDC Communications Interface class */
    driver.classcheck   = &usb_hstd_class_check;
    driver.statediagram = &usb_hcdc_device_state;
    usb_hstd_driver_registration (&driver);

} /* eof usb_hcdc_registration() */

/******************************************************************************
 * Function Name: usb_hcdc_device_state
 * Description  : Open / Close
 * Arguments    : uint16_t data          : Device address
                : uint16_t state            : Device state
 * Return Value : none
 ******************************************************************************/
static void usb_hcdc_device_state (uint16_t data, uint16_t state)
{
    usb_ctrl_t  ctrl;
#if USB_CFG_COMPLIANCE == USB_CFG_ENABLE
    usb_compliance_t disp_param;
#endif /* USB_CFG_COMPLIANCE == USB_CFG_ENABLE */

    switch( state )
    {
        case USB_STS_DETACH:
#if USB_CFG_COMPLIANCE == USB_CFG_ENABLE
            disp_param.status = USB_CT_DETACH;
            disp_param.pid    = USB_NULL;
            disp_param.vid    = USB_NULL;
            usb_compliance_disp ((void *)&disp_param);

#endif /* USB_CFG_COMPLIANCE == USB_CFG_ENABLE */
            usb_cstd_pipe_reg_clear ();
            usb_cstd_pipe_table_clear ();

            usb_cstd_set_event (USB_STS_DETACH, &ctrl);
        break;

        case USB_STS_ATTACH:
#if USB_CFG_BC == USB_CFG_ENABLE
            if (USB_BC_STATE_CDP == data)
            {
                usb_cstd_set_event (USB_STS_BC, &ctrl);
            }

#endif /* USB_CFG_BC == USB_CFG_ENABLE */


#if USB_CFG_COMPLIANCE == USB_CFG_ENABLE
            disp_param.status = USB_CT_ATTACH;
            disp_param.pid    = USB_NULL;
            disp_param.vid    = USB_NULL;
            usb_compliance_disp ((void *)&disp_param);

#endif /* USB_CFG_COMPLIANCE == USB_CFG_ENABLE */
        break;

        case USB_STS_DEFAULT:
        break;

        case USB_STS_CONFIGURED:
            usb_cstd_pipe_reg_set ();
            ctrl.type = USB_HCDC;
            usb_cstd_set_event (USB_STS_CONFIGURED, &ctrl);
        break;

        case USB_STS_SUSPEND:
        break;

        case USB_STS_RESUME:
            usb_cstd_set_event (USB_STS_RESUME, &ctrl);
        break;

        case USB_STS_OVERCURRENT:
            usb_cstd_set_event (USB_STS_OVERCURRENT, &ctrl);
        break;

        default:
        break;
    }

}   /* eof usb_hcdc_device_state() */

#endif /*(BSP_CFG_RTOS_USED == 0)*/

#endif /* defined(USB_CFG_HCDC_USE) */
/******************************************************************************
End Of File
 ******************************************************************************/
