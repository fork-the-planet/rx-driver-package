
/*  ---------------------------------------------------------------
    /*
* Copyright (c) 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/    
    /* ---------------------------------------------------------------
 */
/* 
 * File Auto-Generated (not modified) 
 */ 

#ifndef ptxNSC_uCODE_H_
#define ptxNSC_uCODE_H_

#include <stdint.h>

#include <stddef.h>

extern const char *ptxNSC_uCODE_SRC;
extern const uint32_t ptxNSC_uCODE_SRC_REV;
extern const char *ptxNSC_uCODE_ASM;
extern const uint32_t ptxNSC_uCODE_ASM_REV;

#define NUM_OF_SECTIONS 2

extern const size_t ptxNSC_uCODE_init_adds [NUM_OF_SECTIONS] ;

#define SIZE_OF_SECTION_0 2

extern const uint8_t ptxNSC_uCODE_section_0 [SIZE_OF_SECTION_0];
#define SIZE_OF_SECTION_1 16202

extern const uint8_t ptxNSC_uCODE_section_1 [SIZE_OF_SECTION_1];
extern const uint8_t *ptxNSC_uCODE_sections [NUM_OF_SECTIONS];
extern const size_t ptxNSC_uCODE_sections_size [NUM_OF_SECTIONS]; 

#endif /*Guard*/
