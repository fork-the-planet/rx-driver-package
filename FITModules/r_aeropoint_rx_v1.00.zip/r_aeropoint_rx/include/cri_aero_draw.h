/****************************************************************************
 *
 * CRI Middleware SDK
 *
 * Copyright (c) 2018 CRI Middleware Co., Ltd.
 *
 * Library  : Aeropoint Lite Runtime
 * Module   : Library System Header
 * File     : cri_aero_draw.h
 *
 ****************************************************************************/

#ifndef CRI_AERO_DRAW_H
#define CRI_AERO_DRAW_H

#include "cri_aero_slide.h"

#endif	

