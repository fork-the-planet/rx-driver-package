/*
* Copyright (C) 2006-2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/***********************************************************************************************************************
* File Name	   : r_rgb2ycc.c
* Description  : Converts from RGB to YCbCr
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_stdint.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define NUM_COEFF	(8)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
#pragma section _jpeg_cmp_F

typedef union
{
	int16_t word[NUM_COEFF];
	int32_t	longWord[NUM_COEFF/2];
} CoeffData;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
const CoeffData coeffData =
{
#ifdef __LIT
	0x4b23,		// +0.58700
	0x2646,		// +0.29900
	0x0e98,		// + 0.11400
	0xea68,		// -0.16874
	0xd59a,		// - 0.33126
	0x4000,		// + 0.50000
	0xf599,		// - 0.08131
	0xca69,		// - 0.41869
#else
	0x2646,		// +0.29900
	0x4b23,		// +0.58700
	0xea68,		// -0.16874
	0x0e98,		// + 0.11400
	0x4000,		// + 0.50000
	0xd59a,		// - 0.33126
	0xca69,		// - 0.41869
	0xf599,		// - 0.08131
#endif
};



#pragma section _jpeg_cmp_F
/***********************************************************************************************************************
* Function Name: r_rgb2ycc
* Description  : Converts from RGB to YCbCr
* Arguments    : uint8_t *rgb : RGB data
*              : uint8_t *ycc : YCbCr data
* Return Value : count -
* Return Value : none
***********************************************************************************************************************/
/*
 *	Y  =  0.29900 * R + 0.58700 * G + 0.11400 * B
 *	Cb = -0.16874 * R - 0.33126 * G + 0.50000 * B  + CENTERJSAMPLE
 *	Cr =  0.50000 * R - 0.41869 * G - 0.08131 * B  + CENTERJSAMPLE
 */
#pragma inline_asm r_rgb2ycc
void r_rgb2ycc(const uint8_t *rgb, uint8_t *ycc)
{
	push.l	r6
	push.l	r7

; register r1: rgb
; register r2: ycc

	movu.b	[r1+], r3	;	r
	movu.b	[r1+], r4	;	g
	movu.b	[r1], r5	;	b
	mov.l	#_coeffData, r1

	/*	Y = 0.29900 * R + 0.58700 * G + 0.11400 * B	*/
	mov.l	[r1+], r6
	mov.l	[r1+], r7
	mullo	r6, r4
	shlr	#16, r6		; Shift into lower 16 bits to use coefficient in upper 16 bits
	maclo	r6, r3
	maclo	r7, r5
	shlr	#16, r7		; -0.16874 is placed in lower 16 bits. This coefficient is used to compute Cb.
	racw	#1
	mvfachi	r6
	min  	#000000FFH, r6		; Saturate calculation
	max     #00H,r6
	mov.b   r6, [r2+]

	/*	Cb = -0.16874 * R - 0.33126 * G + 0.50000 * B + 128	*/
	mov.l	[r1+], r6
	mullo	r7, r3
	maclo	r6, r4
	shlr	#16, r6		; +0.50000 is placed in lower 16 bits. This coefficient is used to compute Cr.
	maclo	r6, r5
	racw	#1
	mvfachi	r7
	add		#128, r7
	min  	#000000FFH, r7	; Saturate calculation
	max     #00H, r7
	mov.b   r7, [r2+]
	mov.l	[r1+], r7

	/*	Cr = 0.50000 * R - 0.41869 * G - 0.08131 * B + 128	*/
	mullo	r6, r3
	maclo	r7, r5
	shlr	#16, r7
	maclo	r7, r4
	racw	#1
	mvfachi	r7
	add		#128, r7
	min  	#000000FFH, r7		; Saturate calculation
	max     #00H, r7
	mov.b   r7, [r2]

	pop	r7
	pop	r6
}
