#include "LCD_SIM.h"

void SIM_GUI_ShowDevice(int OnOff);

void SIM_X_Config() {
  SIM_GUI_ShowDevice(0);
}
