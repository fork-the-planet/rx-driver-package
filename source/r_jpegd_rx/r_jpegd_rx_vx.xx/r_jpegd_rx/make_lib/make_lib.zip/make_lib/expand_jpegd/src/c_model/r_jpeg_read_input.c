/*
* Copyright (C) 2006-2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/*******************************************************************************
* File Name     : r_expand.c
* Version       :
* Device(s)     :
* Tool-Chain    :
* H/W Platform  :
* Description   : The supplement of an input buffer (dummy function)
******************************************************************************/

/******************************************************************************
Includes <System Includes> , "Project Includes"
******************************************************************************/
#include "r_jpegd.h"
#include "r_expand_jpegd.h"

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/

/******************************************************************************
Functions
******************************************************************************/
#pragma section _jpeg_exp_S

/******************************************************************************
* Declaration       : void R_jpeg_read_input(struct _jpeg_working *wenv)
* Function Name     : R_jpeg_read_input
* Description       : The dummy of a user-defined function
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : none
******************************************************************************/
void R_jpeg_read_input(struct _jpeg_working *wenv)
{
}

