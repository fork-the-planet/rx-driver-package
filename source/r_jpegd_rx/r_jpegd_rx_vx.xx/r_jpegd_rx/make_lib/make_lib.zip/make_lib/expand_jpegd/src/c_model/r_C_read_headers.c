/*
* Copyright (C) 2006-2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/***********************************************************************************************************************
* File Name     : r_C_read_headers.c
* Version       :
* Device(s)     :
* Tool-Chain    :
* H/W Platform  :
* Description   : Header analysis
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 15.11.2024 2.07     Added WAIT_LOOP comment.
*         : 20.03.2025 2.08     Changed the disclaimer in program sources
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_jpegd.h"
#include "r_expand_jpegd.h"
#include "r_jpeg_maker.h"

/***********************************************************************************************************************
Typedef definitions
 **********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define FUNC_ERROR				(-1)
#define FUNC_EXIT				(0)
#define FUNC_CONTINUE			(1)

#define _JPEG_NUM_QUANT_TBLS	(4)		/* Quantization tables are numbered 0..3 */
#define _JPEG_MAX_COMPS_IN_SCAN	(4)		/* JPEG limit on # of components in one scan */

#define JFIF_LEN				(14)

/***********************************************************************************************************************
Imported global variables and functions (from other files)
***********************************************************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
***********************************************************************************************************************/

/******************************************************************************
Private global variables and functions
***********************************************************************************************************************/
#pragma section _jpeg_exp_S

static int16_t _jpeg_readMarkers(struct _jpeg_working *, int32_t use_table);
static int16_t _jpeg_readSOF0(struct _jpeg_working *);
static int16_t _jpeg_readSOS(struct _jpeg_working *);
static int16_t _jpeg_readAPP0(struct _jpeg_working *);
static int16_t _jpeg_readAPP14(struct _jpeg_working *);
static int16_t _jpeg_readDHT(struct _jpeg_working *);
static int16_t _jpeg_readDQT(struct _jpeg_working *);
static int16_t _jpeg_skipMarkerSegment(struct _jpeg_working *);
static int16_t _jpeg_noSupportMarkers(struct _jpeg_working *);
static int16_t _jpeg_readDRI(struct _jpeg_working *);
static int16_t _jpeg_checkSOI(struct _jpeg_working *);
static int16_t _jpeg_checkTableConsistency(struct _jpeg_working *);

static int16_t (*const _jpeg_markerActions[2][4 * 16])(struct _jpeg_working *) =
{
	/* normal version */
	{
		/* from 0xC0 to 0xCF */
		_jpeg_readSOF0,						/* SOF0 --- Baseline DCT */
		_jpeg_noSupportMarkers,				/* SOF1 */
		_jpeg_noSupportMarkers,				/* SOF2 */
		_jpeg_noSupportMarkers,				/* SOF3 */
		_jpeg_readDHT,						/* DHT --- Define Huffman table(s) */
		_jpeg_noSupportMarkers,				/* SOF5 */
		_jpeg_noSupportMarkers,				/* SOF6 */
		_jpeg_noSupportMarkers,				/* SOF7 */
		_jpeg_noSupportMarkers,				/* JPG */
		_jpeg_noSupportMarkers,				/* SOF9 */
		_jpeg_noSupportMarkers,				/* SOF10 */
		_jpeg_noSupportMarkers,				/* SOF11 */
		_jpeg_noSupportMarkers,				/* DAC */
		_jpeg_noSupportMarkers,				/* SOF13 */
		_jpeg_noSupportMarkers,				/* SOF14 */
		_jpeg_noSupportMarkers,				/* SOF15 */

		/* from 0xD0 to 0xDF */
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,	/* RSTm */
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers,				/* SOI --- Start of image */
		_jpeg_noSupportMarkers,				/* EOI --- End of image */
		_jpeg_readSOS,						/* SOS --- Start of scan */
		_jpeg_readDQT,						/* DQT --- Define quantization table(s) */
		_jpeg_skipMarkerSegment,			/* DNL --- Ignore DNL */
		_jpeg_readDRI,						/* DRI --- Define restart Interval */
		_jpeg_noSupportMarkers,				/* DHP */
		_jpeg_noSupportMarkers,				/* EXP */

		/* from 0xE0 to 0xEF */	/* APPn, where n=1,2, ..., f */
		_jpeg_readAPP0,						/* APP0 */
		_jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_readAPP14,					/* APP14 */
		_jpeg_skipMarkerSegment,

		/* from 0xF0 to 0xFF */
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,	/* JPGn, where n=0,1, ..., d */
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_skipMarkerSegment,			/* COM */
		_jpeg_noSupportMarkers
	},
	/* light version */
	{
		/* from 0xC0 to 0xCF */
		_jpeg_readSOF0,						/* SOF0 --- Baseline DCT */
		_jpeg_noSupportMarkers,				/* SOF1 */
		_jpeg_noSupportMarkers,				/* SOF2 */
		_jpeg_noSupportMarkers,				/* SOF3 */
		_jpeg_skipMarkerSegment,			/* [skip] DHT --- Define Huffman table(s) */
		_jpeg_noSupportMarkers,				/* SOF5 */
		_jpeg_noSupportMarkers,				/* SOF6 */
		_jpeg_noSupportMarkers,				/* SOF7 */
		_jpeg_noSupportMarkers,				/* JPG */
		_jpeg_noSupportMarkers,				/* SOF9 */
		_jpeg_noSupportMarkers,				/* SOF10 */
		_jpeg_noSupportMarkers,				/* SOF11 */
		_jpeg_noSupportMarkers,				/* DAC */
		_jpeg_noSupportMarkers,				/* SOF13 */
		_jpeg_noSupportMarkers,				/* SOF14 */
		_jpeg_noSupportMarkers,				/* SOF15 */

		/* from 0xD0 to 0xDf */
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,	/* RSTm */
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers,				/* SOI --- Start of image */
		_jpeg_noSupportMarkers,				/* EOI --- End of image */
		_jpeg_readSOS,						/* SOS --- Start of scan */
		_jpeg_skipMarkerSegment,			/* [skip] DQT --- Define quantization table(s) */
		_jpeg_skipMarkerSegment,			/* DNL --- Ignore DNL */
		_jpeg_skipMarkerSegment,			/* [skip] DRI --- Define restart Interval */
		_jpeg_noSupportMarkers,				/* DHP */
		_jpeg_noSupportMarkers,				/* EXP */

		/* from 0xE0 to 0xEF */	/* APPn, where n=1,2, ..., f */
		_jpeg_readAPP0,						/* APP0 */
		_jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_skipMarkerSegment, _jpeg_skipMarkerSegment,
		_jpeg_readAPP14,					/* APP14 */
		_jpeg_skipMarkerSegment,

		/* from 0xF0 to 0xFF */
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,	/* JPGn, where n=0,1, ..., d */
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_noSupportMarkers, _jpeg_noSupportMarkers,
		_jpeg_skipMarkerSegment,			/* COM */
		_jpeg_noSupportMarkers
	}
};


/***********************************************************************************************************************
Functions
***********************************************************************************************************************/
#pragma section _jpeg_exp_S

/***********************************************************************************************************************
* Declaration       : int16_t _jpeg_read_header(struct _jpeg_working *wenv, int32_t use_table)
* Function Name     : _jpeg_read_header
* Description       : Header analysis
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
*                   : use_table - use table type. 0=normal, 1=light
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
int16_t
_jpeg_read_header(struct _jpeg_working *wenv, int32_t use_table)
{
	int16_t ret;

	/* first, check SOI */
	ret = _jpeg_checkSOI(wenv);
	if (ret != _JPEGD_OK)
	{
		return ret;
	}

	/* check other Markers */
	ret = _jpeg_readMarkers(wenv, use_table);
	if (ret != _JPEGD_OK)
	{
		return ret;
	}

	if (use_table == _READ_HEADER_FOR_EXPAND)
	{
		/* check Consistency */
		ret = _jpeg_checkTableConsistency(wenv);
		if (ret != _JPEGD_OK)
		{
			return ret;
		}
	}
	return EXPAND_JPEGD_OK;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_readMarkers(struct _jpeg_working *wenv, int32_t use_table)
* Function Name     : _jpeg_readMarkers
* Description       : A marker is detected and each processing is called
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
*                   : use_table - use table type. 0=normal, 1=light
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_readMarkers(struct _jpeg_working *wenv, int32_t use_table)
{
	int16_t n;
	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;

	/* Outer loop repeats once for each marker. */
	/* WAIT_LOOP */
	for (;;)
	{
		uint8_t c;

		CHECK_BYTES(2, wenv);
		INPUT_BYTE(c, wenv, decFMB);
		if (c != _JPEG_MARKER)
		{
			return EXPAND_JPEGD_ERROR_HEADER;
		}

		INPUT_BYTE(c, wenv, decFMB);

		if (c < 0xc0)
		{
			return EXPAND_JPEGD_ERROR_HEADER;		/* treat as errors anyway */
		}
		STREAM_HEADER_FLAG_SET(wenv->decSMB, c - 0xc0);
		n = (*(_jpeg_markerActions[use_table][c - 0xc0]))(wenv);
		if (n == FUNC_EXIT)
		{
			if (STREAM_HEADER_FLAG_CHECK(wenv->decSMB) == 0)
			{
				return EXPAND_JPEGD_ERROR_HEADER;
			}
			return EXPAND_JPEGD_OK;
		}
		if (n != FUNC_CONTINUE)
		{
			return EXPAND_JPEGD_ERROR_HEADER;
		}
		/* otherwise, n == FUNC_CONTINUE to continue */
	}				/* end of for (;;) */
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_readSOF0(struct _jpeg_working *wenv)
* Function Name     : _jpeg_readSOF0
* Description       : SOF0 processing
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_readSOF0(struct _jpeg_working *wenv)
{
	int32_t length;
	int16_t i;
	uint8_t n, c;
	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;
	struct _jpeg_dec_SMB *decSMB = wenv->decSMB;
	struct component_info *cinfo;

	if (STREAM_HEADER_CHECK_SOF0(decSMB->flagStreamHeader[0]))
	{
		return FUNC_ERROR;
	}
	READ_LENGTH(length, wenv, decFMB);

	INPUT_BYTE(_jpeg_d_precision(decSMB), wenv, decFMB);
	INPUT_2BYTES(_jpeg_d_number_of_lines(decSMB), wenv, decFMB);
	INPUT_2BYTES(_jpeg_d_line_length(decSMB), wenv, decFMB);
	INPUT_BYTE(n, wenv, decFMB);
	_jpeg_d_num_of_components(decSMB) = n;
	length -= 6;

	if (_jpeg_d_number_of_lines(decSMB) <= 0 || _jpeg_d_line_length(decSMB) <= 0)
	{
		return FUNC_ERROR;
	}
	if (n > _JPEG_COMPONENT_NUM || n <= 0)
	{
		return FUNC_ERROR;
	}

	cinfo = &(component_info(decSMB));
    /* WAIT_LOOP */
	for (i = 0; i < n; ++i /* , ++cinfo */)
	{
		INPUT_BYTE(cinfo->component_id[i], wenv, decFMB);
		INPUT_BYTE(c, wenv, decFMB);
		cinfo->hsample_ratio[i] = (c >> 4) & 15;
		cinfo->vsample_ratio[i] = c & 15;
		INPUT_BYTE(cinfo->quant_tbl_no[i], wenv, decFMB);
	}

	return FUNC_CONTINUE;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_readSOS(struct _jpeg_working *wenv)
* Function Name     : _jpeg_readSOS
* Description       : SOS processing
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_readSOS(struct _jpeg_working *wenv)
{
	int32_t length;
	int16_t i, j;
	uint8_t n, c;
	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;
	struct _jpeg_dec_SMB *decSMB = wenv->decSMB;
	struct component_info *cinfo;
	struct frame_component_info *finfo;

	if (STREAM_HEADER_CHECK_SOS(decSMB->flagStreamHeader[0]))
	{
		return FUNC_ERROR;
	}
	READ_LENGTH(length, wenv, decFMB);

	INPUT_BYTE(n, wenv, decFMB);		/* Number of components */

	if (length != (n * 2 + 4) || n < 1 || n > _JPEG_MAX_COMPS_IN_SCAN)
	{
		return FUNC_ERROR;
	}

	_jpeg_d_frame_num_of_components(decSMB) = n;

	/* Collect the component-spec parameters */

	finfo = &(frame_component_info(decSMB));
	cinfo = &(component_info(decSMB));
    /* WAIT_LOOP */
	for (i = 0; i < n; ++i)
	{
		INPUT_BYTE(c, wenv, decFMB);
        /* WAIT_LOOP */
		for (j = 0; j < _jpeg_d_num_of_components(decSMB); ++j)
		{
			if (c == (uint8_t)(cinfo->component_id[j]))
			{
				goto component_id_found;
			}
		}
		return FUNC_ERROR;

component_id_found:
		finfo->component_id[i] = c;
		INPUT_BYTE(c, wenv, decFMB);
		finfo->dc_tbl_no[i] = (c >> 4) & 15;
		finfo->ac_tbl_no[i] = (c) & 15;
	}

	INPUT_BYTE(c, wenv, decFMB);	/* Ss: Start of spectral or predictor section */
	if (c != 0)
	{
		return FUNC_ERROR;
	}
	INPUT_BYTE(c, wenv, decFMB);	/* Se: End of spectral or predictor section */
	if (c != 63)
	{
		return FUNC_ERROR;
	}
	INPUT_BYTE(c, wenv, decFMB);	/* Ah/Al: Successive approximation bit position high/low */
	if (c != 0)
	{
		return FUNC_ERROR;
	}

	return FUNC_EXIT;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_readAPP0(struct _jpeg_working *wenv)
* Function Name     : _jpeg_readAPP0
* Description       : APP0 processing
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_readAPP0(struct _jpeg_working *wenv)
{
	int32_t length;
	uint8_t data[JFIF_LEN];
	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;
	struct _jpeg_dec_SMB *decSMB = wenv->decSMB;

	READ_LENGTH(length, wenv, decFMB);

	if (length >= JFIF_LEN)
	{
		READ_NBYTE(data, JFIF_LEN, wenv, decFMB);
		length -= JFIF_LEN;

		if (data[0] == 'J' && data[1] == 'F' && data[2] == 'I' && data[3] == 'F' && data[4] == 0)
		{
			/*
			 *	Found JFIF APP0 marker: check version
			 */
			_jpeg_X_density(decSMB) = (data[8] << 8) + data[9];
			_jpeg_Y_density(decSMB) = (data[10] << 8) + data[11];

			if (length != ((long int) data[12] * (long int) data[13] * 3))
			{
				return FUNC_ERROR;
			}
		}
		else
		{
			return FUNC_ERROR;
		}
	}
	else
	{
		/* Too short to be JFIF marker */
		return FUNC_ERROR;
	}

	if (length > 0)  		/* skip any remaining data -- could be lots */
	{
		SKIP_BYTES(length, wenv, decFMB);
	}

	return FUNC_CONTINUE;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_readAPP14(struct _jpeg_working *wenv)
* Function Name     : _jpeg_readAPP14
* Description       : APP14 processing, without real processing
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_readAPP14(struct _jpeg_working *wenv)
{
#define ADOBE_LEN 12
	int32_t length;
	uint8_t data[ADOBE_LEN];
	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;

	READ_LENGTH(length, wenv, decFMB);

	if (length >= ADOBE_LEN)
	{
		READ_NBYTE(data, ADOBE_LEN, wenv, decFMB);
		length -= ADOBE_LEN;

		if (data[0] == 0x41 && data[1] == 0x64 && data[2] == 0x6f && data[3] == 0x62 && data[4] == 0x65)
		{
			/*
			 *	Found Adobe APP14 marker
			 *	May check version, etc.
			 */
			/* printf("Adobe APP14 marker\n"); */
		}
	}

	if (length > 0)  		/* skip any remaining data -- could be lots */
	{
		SKIP_BYTES(length, wenv, decFMB);
	}

	return FUNC_CONTINUE;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_readDHT(struct _jpeg_working *wenv)
* Function Name     : _jpeg_readDHT
* Description       : DHT processing
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_readDHT(struct _jpeg_working *wenv)
{
	int32_t length;
	uint8_t bits[_JPEG_BITS_SIZE];
	uint8_t *huffval, *phuff;
	int16_t i, count, n;
	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;
	int16_t ret;
	uint8_t index;

	READ_LENGTH(length, wenv, decFMB);
	huffval = (uint8_t *)_jpeg_work(decFMB);
    /* WAIT_LOOP */
	while (length > 0)
	{
		INPUT_BYTE(index, wenv, decFMB);
		bits[0] = 0;
		count = 0;
        /* WAIT_LOOP */
		for (i = 1; i < _JPEG_BITS_SIZE; ++i)
		{
			INPUT_BYTE(bits[i], wenv, decFMB);
			count += bits[i];
		}

		length -= (1 + (_JPEG_BITS_SIZE - 1));

		if (count > _JPEG_HUFFVAL_SIZE || ((long int) count) > length)
		{
			return FUNC_ERROR;
		}

		phuff = huffval;
        /* WAIT_LOOP */
		for (i = count; i; --i)
		{
			INPUT_BYTE(*phuff++, wenv, decFMB);
		}

		length -= count;

		ret = R_jpeg_make_huff_table(index, huffval, bits, count, wenv);
		if (ret != _JPEGD_OK)
		{
			return FUNC_ERROR;
		}
		n = DHT_INDEX2N(index);
		STREAM_HEADER_DHT_SET(wenv->decSMB, n);
	}

	return FUNC_CONTINUE;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_readDQT(struct _jpeg_working *wenv)
* Function Name     : _jpeg_readDQT
* Description       : DQT processing
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_readDQT(struct _jpeg_working *wenv)
{
	int32_t length;
	int16_t i;
	uint8_t n, prec;
	uint16_t tmp;
	uint32_t qtbl[_JPEG_DCTSIZE2/2];
	uint16_t *quant_ptr;
	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;
	int16_t ret;

	READ_LENGTH(length, wenv, decFMB);

    /* WAIT_LOOP */
	while (length > 0)
	{
		INPUT_BYTE(n, wenv, decFMB);
		prec = n >> 4;
		n &= 0x0F;

		if (n >= _JPEG_NUM_QUANT_TBLS)
		{
			return FUNC_ERROR;
		}
		quant_ptr = (uint16_t *)qtbl;

		if (prec == 0)
		{
            /* WAIT_LOOP */
			for (i = _JPEG_DCTSIZE2; i; --i)
			{
				INPUT_BYTE(tmp, wenv, decFMB);	/* 8bit */
				*quant_ptr++ = tmp;
			}
		}
		else
		{
			return FUNC_ERROR;
		}
		length -= _JPEG_DCTSIZE2 + 1;
		if (prec)
		{
			length -= _JPEG_DCTSIZE2;
		}
		ret = R_jpeg_add_iquant_table(n, (uint16_t *)qtbl, wenv);
		if (ret != _JPEGD_OK)
		{
			return FUNC_ERROR;
		}
		STREAM_HEADER_DQT_SET(wenv->decSMB, n);
	}

	return FUNC_CONTINUE;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_skipMarkerSegment(struct _jpeg_working *wenv)
* Function Name     : _jpeg_skipMarkerSegment
* Description       : Skip in reading of the data in a marker. Heder analysis is continuing
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_skipMarkerSegment(struct _jpeg_working *wenv)
{
	int32_t length;
	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;

	READ_LENGTH(length, wenv, decFMB);

	SKIP_BYTES(length, wenv, decFMB);
	return FUNC_CONTINUE;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_noSupportMarkers(struct _jpeg_working *wenv)
* Function Name     : _jpeg_noSupportMarkers
* Description       : Marker detection outside of support. Heder analysis is error finish
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_noSupportMarkers(struct _jpeg_working *wenv)
{
	return FUNC_ERROR;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_readDRI(struct _jpeg_working *wenv)
* Function Name     : _jpeg_readDRI
* Description       : DRI processing
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_readDRI(struct _jpeg_working *wenv)
{
	int32_t length;
	uint16_t var;
	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;

	READ_LENGTH(length, wenv, decFMB);
	if (length != 2)
	{
		return FUNC_ERROR;
	}
	INPUT_2BYTES(var, wenv, decFMB);
	_jpeg_restart_interval(decFMB) = var;

	return FUNC_CONTINUE;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_checkSOI(struct _jpeg_working *wenv)
* Function Name     : _jpeg_checkSOI
* Description       : SOI check
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_checkSOI(struct _jpeg_working *wenv)
{
	uint8_t c;
	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;

	/* first, check SOI */
	INPUT_BYTE(c, wenv, decFMB);
	if (c != _JPEG_MARKER)
	{
		return EXPAND_JPEGD_ERROR_SOI;
	}
	INPUT_BYTE(c, wenv, decFMB);
	if (c != _JPEG_MARKER_SOI)
	{
		return EXPAND_JPEGD_ERROR_SOI;
	}
	STREAM_HEADER_FLAG_SET(wenv->decSMB, c - 0xc0);

	return EXPAND_JPEGD_OK;
}

/***********************************************************************************************************************
* Declaration       : int16_t _jpeg_checkEOI(struct _jpeg_working *wenv)
* Function Name     : _jpeg_checkEOI
* Description       : EOI check
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
int16_t
_jpeg_checkEOI(struct _jpeg_working *wenv)
{
	uint8_t c;

	struct _jpeg_dec_FMB *decFMB = wenv->decFMB;
	CHECK_BYTES(2, wenv);
	INPUT_BYTE(c, wenv, decFMB);
	if (c != _JPEG_MARKER)
	{
		return EXPAND_JPEGD_ERROR_EOI;
	}
	INPUT_BYTE(c, wenv, decFMB);
	if (c != _JPEG_MARKER_EOI)
	{
		return EXPAND_JPEGD_ERROR_EOI;
	}

	return EXPAND_JPEGD_OK;
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_checkTableConsistency(struct _jpeg_working *wenv)
* Function Name     : _jpeg_checkTableConsistency
* Description       : Checks the consistency of a table.
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_checkTableConsistency(struct _jpeg_working *wenv)
{
	int16_t i, j;
	uint8_t n, nf;
	struct _jpeg_dec_SMB *decSMB = wenv->decSMB;
	struct component_info *cinfo;
	struct frame_component_info *finfo;

	n = _jpeg_d_num_of_components(decSMB);
	nf = _jpeg_d_frame_num_of_components(decSMB);
	cinfo = &(component_info(decSMB));
	finfo = &(frame_component_info(decSMB));
    /* WAIT_LOOP */
	for (i = 0; i < n; ++i)
	{
		if (STREAM_HEADER_CHECK_QUNAT_TABLE(decSMB, cinfo->quant_tbl_no[i]) == 0)
		{
			return EXPAND_JPEGD_ERROR_HEADER;
		}
        /* WAIT_LOOP */
		for (j = 0; j < nf; ++j)
		{
			if (cinfo->component_id[i] == finfo->component_id[j])
			{
				if (STREAM_HEADER_CHECK_DC_TABLE(decSMB, finfo->dc_tbl_no[j]) == 0)
				{
					return EXPAND_JPEGD_ERROR_HEADER;
				}
				if (STREAM_HEADER_CHECK_AC_TABLE(decSMB, finfo->ac_tbl_no[j]) == 0)
				{
					return EXPAND_JPEGD_ERROR_HEADER;
				}
				break;
			}
		}
		if (j == nf)
		{
			return EXPAND_JPEGD_ERROR_HEADER;
		}
	}

	return EXPAND_JPEGD_OK;
}
