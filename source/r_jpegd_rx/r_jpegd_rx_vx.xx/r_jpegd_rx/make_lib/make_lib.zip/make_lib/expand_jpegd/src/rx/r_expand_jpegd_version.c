/*
* Copyright (C) 2006-2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/*******************************************************************************
* File Name     : r_expand_jpegd_version.c
* Version       :
* Device(s)     : RX Family
* Tool-Chain    :
* H/W Platform  :
* Description   : Version information
* Operation     :
******************************************************************************/

/******************************************************************************
Includes <System Includes> , "Project Includes"
******************************************************************************/
#include "r_stdint.h"
#include "r_mw_version.h"

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define __EXP_JPEGD_VERSION__ "1.03"

#if   (defined	(__RX600) && defined (__BIG))
#define __TARGET_CPU__ "RX600 BIG endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#elif (defined	(__RX600) && defined (__LIT))
#define __TARGET_CPU__ "RX600 LITTLE endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#elif (defined	(__RX200) && defined (__BIG))
#define __TARGET_CPU__ "RX200 BIG endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#elif (defined	(__RX200) && defined (__LIT))
#define __TARGET_CPU__ "RX200 LITTLE endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#else
#error "None-support combination of CPU and endian"
#endif

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
#pragma section _jpeg_exp_S

const mw_version_t R_expand_jpegd_version =
{
	__COMPILER_VER__ ,
	"JPEG File Expand Library version "__EXP_JPEGD_VERSION__" for the "__TARGET_CPU__".("__DATE__", "__TIME__")\n"
};

/******************************************************************************
Private global variables and functions
******************************************************************************/
