/*
* Copyright (C) 2006-2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/*******************************************************************************
* File Name     : r_jpeg_maker.h
* Version       :
* Device(s)     :
* Tool-Chain    :
* H/W Platform  :
* Description   : Marker definition
*******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define _JPEG_MARKER		(0xff)
#define _JPEG_MARKER_SOI	(0xd8)
#define _JPEG_MARKER_EOI	(0xd9)
#define _JPEG_MARKER_SOF0	(0xc0)

#define _READ_HEADER_FOR_EXPAND		(0)
#define _READ_HEADER_FOR_GET_INFO	(1)

