/*
* Copyright (C) 2006-2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/*******************************************************************************
* File Name     : r_rgb2short.h
* Version       :
* Device(s)     :
* Tool-Chain    :
* H/W Platform  :
* Description   : The macro definition of RGB565 conversion
******************************************************************************/

#if !defined(_r_rgb2short_h)
#define _r_rgb2short_h

/******************************************************************************
Macro definitions
******************************************************************************/
#define RGB2SHORT(r, g, b)	RGB2SHORT_##r##g##b

#define MASK_UP5BITS	(0xf8)
#define MASK_UP6BITS	(0xfc)

#define ONEBYTE8BITS	(8)
#define RGB6BITS		(6)
#define RGB5BITS		(5)

/* Case of R:G:B=5:6:5 */
#define SHORT565R		RGB5BITS
#define SHORT565G		RGB6BITS
#define SHORT565B		RGB5BITS
#define RGB2SHORT_R5G6B5(rgb, r, g, b)	\
			rgb = ((r) & MASK_UP5BITS) << (SHORT565G+SHORT565B-(ONEBYTE8BITS-SHORT565R));		\
			rgb |= (((g) & MASK_UP6BITS) << (SHORT565B-(ONEBYTE8BITS-SHORT565G)));		\
			rgb |= ((b) >> (ONEBYTE8BITS-SHORT565B));

#endif

