/*
* Copyright (C) 2015 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/***********************************************************************************************************************
* File Name    : r_s2_version.c
* Version      : 1.02
* Description  : middleware version information definition
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 20.07.2012 1.00     First Release
*         : 20.03.2025 1.01     Changed the disclaimer in program sources
*         : 20.04.2026 1.02     Changed #define _S2_VERSION__
***********************************************************************************************************************/
#include "r_stdint.h"
#include "r_mw_version.h"

/******************************************************************************
Macro definitions
******************************************************************************/
#define __COMPLIER_VER_UNDEFINED__ 0xFFFFFFFF
#define __S2_VERSION__ "3.06"

#if (defined (__RXV2) && defined (__BIG))
#define __TARGET_CPU__ "RXV2 BIG endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (__RXV2) && defined (__LIT))
#define __TARGET_CPU__ "RXV2 LITTLE endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (__RXV1) && defined (__BIG))
#define __TARGET_CPU__ "RXV1 BIG endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (__RXV1) && defined (__LIT))
#define __TARGET_CPU__ "RXV1 LITTLE endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (__RX600) && defined (__BIG))
#define __TARGET_CPU__ "RX600 BIG endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (__RX600) && defined (__LIT))
#define __TARGET_CPU__ "RX600 LITTLE endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (__RX200) && defined (__BIG))
#define __TARGET_CPU__ "RX200 BIG endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (__RX200) && defined (__LIT))
#define __TARGET_CPU__ "RX200 LITTLE endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (_SH4A) && defined(_BIG))
#define __TARGET_CPU__ "SH-4A BIG endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (_SH4A) && defined(_LIT))
#define __TARGET_CPU__ "SH-4A LITTLE endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif defined (_SH2AFPU)
#define __TARGET_CPU__ "SH2A-FPU"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif defined (_SH2A)
#define __TARGET_CPU__ "SH-2A"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (_SH2) && defined(_BIG))
#define __TARGET_CPU__ "SH-2 BIG endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif (defined (_SH2) && defined(_LIT))
#define __TARGET_CPU__ "SH-2 LITTLE endian"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif defined (__v850) && (__v850e2v3)
#define __TARGET_CPU__ "V850E2V3"
#define __COMPILER_VER__   __COMPLIER_VER_UNDEFINED__
#elif defined (__v850) && (__v850e2)
#define __TARGET_CPU__ "V850E2"
#define __COMPILER_VER__   __COMPLIER_VER_UNDEFINED__
#elif defined (__v850) && (__v850e)
#define __TARGET_CPU__ "V850E"
#define __COMPILER_VER__   __COMPLIER_VER_UNDEFINED__
#elif defined (__v850)
#define __TARGET_CPU__ "V850"
#define __COMPILER_VER__   __COMPLIER_VER_UNDEFINED__
#elif defined (__K0__)
#define __TARGET_CPU__ "78K0"
#define __COMPILER_VER__   __COMPLIER_VER_UNDEFINED__
#elif defined (__CCRL__)
#if defined (__RL78_SMALL__)
#define __MEMORY_MODEL__ "SMALL"
#elif defined (__RL78_MEDIUM__)
#define __MEMORY_MODEL__ "MEDIUM"
#else
#error "Undefined memory model."
#endif
#if defined (__RL78_S1__)
#define __CORE_NAME__ "S1"    /* RL78/G10 */
#elif defined (__RL78_S2__)
#define __CORE_NAME__ "S2"    /* RL78/G12 RL78/G13 */
#elif defined (__RL78_S3__)
#define __CORE_NAME__ "S3"    /* RL78/G14 */
#else
#error "Undefined CPU Core."
#endif
#define __TARGET_CPU__ "RL78 (CCRL, "__CORE_NAME__", "__MEMORY_MODEL__")"
#define __COMPILER_VER__   __RENESAS_VERSION__
#elif defined (__K0R__)
#if defined (__RL78__)
#if defined (__K0R_SMALL__)
#define __MEMORY_MODEL__ "SMALL"
#elif defined (__K0R_MEDIUM__)
#define __MEMORY_MODEL__ "MEDIUM"
#elif defined (__K0R_LARGE__)
#define __MEMORY_MODEL__ "LARGE"
#else
#error "Undefined memory model."
#endif
#if defined (__RL78_1__)
#define __CORE_NAME__ "S2"    /* RL78/G12 RL78/G13 */
#elif defined (__RL78_2__)
#define __CORE_NAME__ "S3"    /* RL78/G14 */
#elif defined (__RL78_3__)
#define __CORE_NAME__ "S1"    /* RL78/G10 */
#else
#error "Undefined CPU Core."
#endif
#define __TARGET_CPU__ "RL78 ("__CORE_NAME__", "__MEMORY_MODEL__")"
#else
#define __TARGET_CPU__ "78K0R"
#endif
#define __COMPILER_VER__   __COMPLIER_VER_UNDEFINED__
#elif defined (__ICCRL78__)
#if __CORE__==__RL78_0__
#define __CORE_NAME__ "S1"   /* RL78/G10 */
#elif __CORE__==__RL78_1__
#define __CORE_NAME__ "S2"   /* RL78/G12 RL78/G13 */
#elif __CORE__==__RL78_2__
#define __CORE_NAME__ "S3"   /* RL78/G14 */
#else
#error "Undefined CPU Core."
#endif
#if __CODE_MODEL__==__CODE_MODEL_NEAR__
#define __CODE_MODEL_NAME__ "code_model=near"
#else
#define __CODE_MODEL_NAME__ "code_model=far"
#endif
#if __DATA_MODEL__==__DATA_MODEL_NEAR__
#define __DATA_MODEL_NAME__ "data_model=near"
#else
#define __DATA_MODEL_NAME__ "data_model=far"
#endif
#define __TARGET_CPU__ "RL78 (IAR, "__CORE_NAME__", "__CODE_MODEL_NAME__", "__DATA_MODEL_NAME__")"
#define __COMPILER_VER__   __VER__
#elif defined (M16C) && defined(__R8C__)
#define __TARGET_CPU__ "R8C"
#ifdef __RENESAS_VERSION__
#define __COMPILER_VER__ __RENESAS_VERSION__
#else
#define __COMPILER_VER__ __COMPLIER_VER_UNDEFINED__
#endif
#elif defined (M16C) && !defined(__R8C__)
#define __TARGET_CPU__ "M16C"
#ifdef __RENESAS_VERSION__
#define __COMPILER_VER__ __RENESAS_VERSION__
#else
#define __COMPILER_VER__ __COMPLIER_VER_UNDEFINED__
#endif
#elif defined (M32C80)
#define __TARGET_CPU__ "M32C/80"
#define __COMPILER_VER__   __COMPLIER_VER_UNDEFINED__
#elif defined (R32C100)
#define __TARGET_CPU__ "R32C/100"
#define __COMPILER_VER__   __COMPLIER_VER_UNDEFINED__
#elif defined (__H8__) && defined(__2600A__)
#define __TARGET_CPU__ "H8S/2600 Advanced mode"
#define __COMPILER_VER__ __RENESAS_VERSION__
#elif defined (_WIN32)
#define __TARGET_CPU__ "Windows OS"
#define __COMPILER_VER__ __COMPLIER_VER_UNDEFINED__
#elif defined (__arm__)
#if defined (__TARGET_CPU_CORTEX_A9)
#if defined (__BIG_ENDIAN)
#define __TARGET_CPU__ "Cortex-A9 BIG endian"
#else
#define __TARGET_CPU__ "Cortex-A9 LITTLE endian"
#endif
#else
#error "Undefined arm CPU."
#endif
#define __COMPILER_VER__ __ARMCC_VERSION
#else
#error "None-support combination of CPU and endian"
#endif

const mw_version_t R_s2_version =
{
    __COMPILER_VER__ ,
    "M3S-S2-Tiny version "__S2_VERSION__" for "__TARGET_CPU__".("__DATE__", "__TIME__")\n"
};
